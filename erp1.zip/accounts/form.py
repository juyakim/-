# form
class SignupForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'email']